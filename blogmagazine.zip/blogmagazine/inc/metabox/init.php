<?php
/**
 * Sidebar Metabox
 */
