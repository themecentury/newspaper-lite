<?php
/*
 * Header Panel
 */
require_once blogmagazine_file_directory( 'inc/customizer/header/section-top-header.php' );
require_once blogmagazine_file_directory( 'inc/customizer/header/section-main-navigation.php' );
require_once blogmagazine_file_directory( 'inc/customizer/header/section-ticker-options.php' );