<?php

/*
 * Include widgets fields 
 */
require_once dglib_file_directory('widgets/fields/dg-widget-fields.php');

/*
 * Include widgets fields 
 */
require_once dglib_file_directory('widgets/fields/dg-master-widget.php');
